# user_param.py  case: marin_2_phase treated as open duct

import math
from proteus import default_p
from proteus.mprans import Kappa


# fluid properties
nd = 3
fluid = {}
fluid['water'] = { 'rho':998.2, 'mu':0.001, 'phi':0., 'nu':1.004e-6 }
fluid['air']   = { 'rho':1.205, 'mu':1.807e-5, 'phi':1., 'nu':1.500e-5 }
rho_air     = fluid['air']['rho']
rho_water   = fluid['water']['rho']
nu_air      = fluid['air']['nu']
nu_water    = fluid['water']['nu']
phase = ['water']

nphase = len(phase)

#xwang
weak_bc_penalty_constant = 10.0/nu_water

# Gravity
gravity = [0.,0.,0.]
if nphase > 1: gravity = [0.,0.,-9.8] 

# turbulent
useRANS    = 1      # 0 -- None # 1 -- K-Epsilon # 2 -- K-Omega
ns_closure=0
if useRANS == 1:
    ns_closure = 3
elif useRANS >= 2:
    ns_closure = 4
#-------

spaceOrder = 1
movingDomain = False
#useOnlyVF = True
useMetrics = 1.0

#Numerical parameters
sc = 0.5 # default: 0.5. Test: 0.25
sc_beta = 1.5 # default: 1.5. Test: 1.
epsFact_consrv_diffusion = 1. # default: 1.0. Test: 0.1
ns_forceStrongDirichlet = False
backgroundDiffusionFactor=0.01
if useMetrics:
    ns_shockCapturingFactor  = sc
    ns_lag_shockCapturing = True
    ns_lag_subgridError = True
    ls_shockCapturingFactor  = sc
    ls_lag_shockCapturing = True
    ls_sc_uref  = 1.0
    ls_sc_beta  = sc_beta
    vof_shockCapturingFactor = sc
    vof_lag_shockCapturing = True
    vof_sc_uref = 1.0
    vof_sc_beta = sc_beta
    rd_shockCapturingFactor  =sc
    rd_lag_shockCapturing = False
    epsFact_density    = 3.
    epsFact_viscosity  = epsFact_curvature  = epsFact_vof = epsFact_consrv_heaviside = epsFact_consrv_dirac = epsFact_density
    epsFact_redistance = 0.33
    epsFact_consrv_diffusion = epsFact_consrv_diffusion
    redist_Newton = True#False
    kappa_shockCapturingFactor = sc
    kappa_lag_shockCapturing = True
    kappa_sc_uref = 1.0
    kappa_sc_beta = sc_beta
    dissipation_shockCapturingFactor = sc
    dissipation_lag_shockCapturing = True
    dissipation_sc_uref = 1.0
    dissipation_sc_beta = sc_beta
else:
    ns_shockCapturingFactor  = 0.9
    ns_lag_shockCapturing = True
    ns_lag_subgridError = True
    ls_shockCapturingFactor  = 0.9
    ls_lag_shockCapturing = True
    ls_sc_uref  = 1.0
    ls_sc_beta  = 1.0
    vof_shockCapturingFactor = 0.9
    vof_lag_shockCapturing = True
    vof_sc_uref  = 1.0
    vof_sc_beta  = 1.0
    rd_shockCapturingFactor  = 0.9
    rd_lag_shockCapturing = False
    epsFact_density    = 1.5
    epsFact_viscosity  = epsFact_curvature  = epsFact_vof = epsFact_consrv_heaviside = epsFact_consrv_dirac = epsFact_density
    epsFact_redistance = 0.33
    epsFact_consrv_diffusion = 10.0
    redist_Newton = False#True
    kappa_shockCapturingFactor = 0.9
    kappa_lag_shockCapturing = True#False
    kappa_sc_uref  = 1.0
    kappa_sc_beta  = 1.0
    dissipation_shockCapturingFactor = 0.9
    dissipation_lag_shockCapturing = True#False
    dissipation_sc_uref  = 1.0
    dissipation_sc_beta  = 1.0

# time stepping

dt_init  =0.2 
dt_fixed =0.2
dt_fixed_steps = 10
dt_fixed_steps = 0 

# initial conditions

waterLine_z = 20.0

def IC_signed_distance(x):
    phi_z = x[2]-waterLine_z 
    return phi_z

class IC_field_constant:
    def __init__(self,value): self.value = value
    def uOfXT(self,x,t): return self.value
    def uOfX(self,x):    return self.value

class IC_field_p:
    def __init__(self): pass
    def uOfXT(self,x,t):
        rho_air     = fluid['air']['rho']
        rho_water   = fluid['water']['rho']
        g_component = gravity[2]
        waterLevel  = waterLine_z
        p_air   = rho_air    * g_component * ( default_p.L[2] - waterLevel )
        p_water = rho_water  * g_component * ( waterLevel - x[2] )
        p_hydrostatic = p_air
        if IC_signed_distance(x) < 0: p_hydrostatic = p_water
        return -p_hydrostatic

class IC_field_phi:       
    def __init__(self): pass
    def uOfXT(self,x,t): return IC_signed_distance(x)

IC_field_value = {}
IC_field_value['p'] = 0.
IC_field_value['u'] = 0.5
IC_field_value['v'] = 0.
IC_field_value['w'] = 0.

# mesh and BCs 

filename = 'case_try_turbulent/cyl_01.tetgen'

nominal_mesh_spacing = 0.05

u = IC_field_value['u']
v = IC_field_value['v']
w = IC_field_value['w']
Vmag = math.sqrt( u*u + v*v + w*w )

bc_wall   = { 'type':'NoSlip' }
bc_slip   = { 'type':'FreeSlip' }
bc_inlet  = { 'type':'velocityInlet', 
              'Vmag': Vmag,
              'sdf': IC_signed_distance,
              'fluid': fluid,
              'smoothing': nominal_mesh_spacing,
}
bc_outlet = { 'type':'outflow', 
              'sdf': IC_signed_distance,
              'fluid': fluid,
              'gravity': gravity,
              'waterLevel': waterLine_z,
              'smoothing': nominal_mesh_spacing,
}
bc_open = { 'type':'open' }
bc_interior = { 'type':'interior' }

bc_zone = {}
bc_zone['interior'] = { 'meshtag': 0,  'condition': bc_interior }
bc_zone['cyl']      = { 'meshtag': 7,  'condition': bc_wall }
bc_zone['x0']       = { 'meshtag': 1,  'condition': bc_inlet }
bc_zone['x1']       = { 'meshtag': 2,  'condition': bc_outlet }
bc_zone['y0']       = { 'meshtag': 3,  'condition': bc_slip }
bc_zone['y1']       = { 'meshtag': 4,  'condition': bc_slip }
bc_zone['z0']       = { 'meshtag': 5,  'condition': bc_slip }
bc_zone['z1']       = { 'meshtag': 6,  'condition': bc_slip }
  
ele_fluid  = { 'type':'fluid' }
  
ele_zone = {}
ele_zone['fluid'] = { 'meshtag': 1, 'condition': ele_fluid }
